# Changelog

## Release Notes

### 1.7

-   Some improvements to “Open GitHub Copilot”

### 1.6

-   Copilot code fix suggestions

### 1.5

-   longer completions in most languages

### 1.4

-   support for automatic closing brackets

### 1.3

-   improved notebook support
-   fix status icon rendering
-   add network activity spinner

### 1.2

-   fix extra trailing characters with CRLF line endings
-   handle http/2 goaway errors

### 1.1

-   minor logging fixes

### 1.0

Initial release.
